# Fade and Blur on Hover Data Table

A Pen created on CodePen.io. Original URL: [https://codepen.io/jackrugile/pen/EyABe](https://codepen.io/jackrugile/pen/EyABe).

This is a data table for a jQuery plugin I am working on. I wanted to share the hover effect I am using. If you hover of a table row, the sibling rows will blur and fade out.